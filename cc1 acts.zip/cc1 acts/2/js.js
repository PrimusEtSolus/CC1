const ShowMoreButton = document.getElementById('ShowMoreButton');

const hiddenDiv = document.getElementById('hiddenDiv');

const Image = document.getElementById('Image');

const description = document.getElementById('description');

const ChangeContent = document.getElementById('ChangeContent');

const Back = document.getElementById('Back');

ShowMoreButton.addEventListener('click', () => {
    hiddenDiv.style.display = 'block';
    Image.src = 'img1.jpg'
    description.textContent = 'autumn madness' 
  });
  
  ChangeContent.addEventListener('click', () => {
    Image.src = 'img2.jpg';
    description.textContent = "very sublime";
  });
  
  Back.addEventListener('click', () => {
    hiddenDiv.style.display = 'none';
    ShowMoreButton.style.display = 'block';
  });
