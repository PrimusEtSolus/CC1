function changeImage(x,image)
{
if(x==1)
{
image.src = 'pic2.jpg';
}
if(x==2)
{
image.src = 'profile.1.jpg'
}
}

let myDiv = document.querySelector('div');
myDiv.addEventListener('mouseover', () => {
    myDiv.style.backgroundImage = `url('')`;
});
myDiv.addEventListener('mouseleave', () => {
    myDiv.style.backgroundImage = null;
});