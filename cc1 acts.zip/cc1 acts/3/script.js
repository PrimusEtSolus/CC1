const username = 'admin';

const password = 'test123';

const loginForm = document.getElementById('loginForm');

const messageElement = document.getElementById('message');
//mga variables kumbaga

loginForm.addEventListener('submit', (event) => {
    event.preventDefault();
//event listener na nasa instruction numba 4.
    const UsernameEntered = event.target.elements.username.value;
    const PasswordEntered = event.target.elements.password.value;
//mga returns

    if (UsernameEntered === username && PasswordEntered === password) {
        messageElement.textContent = 'Login successful!';
        window.location.href = 'success.html'
    } else {
        messageElement.textContent = 'Incorrect username or password.';
    }
});
//yung if-else statement pag tama o mali yung input